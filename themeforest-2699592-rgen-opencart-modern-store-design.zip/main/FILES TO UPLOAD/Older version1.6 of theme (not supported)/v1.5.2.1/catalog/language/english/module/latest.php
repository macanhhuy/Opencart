<?php
// Heading 
$_['heading_title'] = 'Latest Products';


// Text
$_['text_reviews']  = 'Based on %s reviews.'; 
?>