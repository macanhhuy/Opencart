<?php
// Heading 
$_['heading_title'] = 'Special Offers';

// Text
$_['text_reviews']  = 'Based on %s reviews.'; 
?>